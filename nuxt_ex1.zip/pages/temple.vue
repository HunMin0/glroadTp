<template>

<div>
  <MainSet />
  <p>asd<br>asd<br>asd<br>asd<br>asd<br>asd<br>asd<br></p>


</div>

</template>

<script>

export default {
  name: 'TemplePage',

}
</script>

<style scoped>

</style>
