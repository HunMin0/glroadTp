<template>
  <v-app>

    <MenuClone/>

    <v-main class="grey lighten-3">
      <Nuxt />
    </v-main>

  </v-app>
</template>

<script>
 export default {

  }
</script>

<style scoped>

</style>
