<template>

    <v-app-bar app color="white" flat inverted-scroll >

    <v-toolbar class='elevation-0'>
      <v-toolbar-title> <NuxtLogo2 /></v-toolbar-title>
    </v-toolbar>

    <v-tabs centered class="ml-n9 openMenu" color="#111 darken-1" background-color="transparent">
     <v-tab v-bind:title="link.tab" class="resize"
      v-for="link in links"
      :key="link.tab"
      :to="link.href"
      :ripple="false"
      >
      {{ link.tab }}
      </v-tab>
    </v-tabs>


    <div class="quickNav">
      <v-app-bar-nav-icon @click="drawer = true" color="#333" large></v-app-bar-nav-icon>

    </div>

    </v-app-bar>

</template>

<script>
 export default {
    data: () => ({
      drawer: false,
      group: null,
      absolute: true,
      links: [
        {tab: 'home', href: '/', icon:'mdi-inbox'},
        {tab: 'subpage1', href: '/temple', icon:'mdi-star'},
        {tab: 'subpage2', href: '/#', icon:'mdi-send'},
        {tab: 'subpage3', href: '/#', icon:'mdi-send'},
        {tab: 'subpage4', href: '/#', icon:'mdi-send'},
      ],
    }),
  }
</script>

<style scoped>
.theme--light.v-tabs .v-tab:hover::before {opacity: 0;}
.theme--light.v-tabs .v-tab--active:focus::before {opacity: 0;}
.v-tab:hover  {color: #333 !important;}
.v-tab:before{display: none;}

#nav {height: 48px; text-align: right; width: 100%;}
</style>
